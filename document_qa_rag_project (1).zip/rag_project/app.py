"""
app.py
------
Run this file to chat with your document.

Usage:
    python app.py sample_docs/sample.txt

Then type questions at the prompt. Type 'exit' to quit.
"""

import sys
from rag_core import load_text, chunk_text, VectorStore
from llm import answer_question


def main():
    if len(sys.argv) < 2:
        print("Usage: python app.py <path_to_text_file>")
        sys.exit(1)

    file_path = sys.argv[1]
    print(f"Loading and indexing: {file_path}")

    text = load_text(file_path)
    chunks = chunk_text(text)
    store = VectorStore()
    store.build(chunks)
    print(f"Indexed {len(chunks)} chunks. Ask away! (type 'exit' to quit)\n")

    while True:
        question = input("You: ").strip()
        if not question:
            continue
        if question.lower() == "exit":
            break

        relevant_chunks = store.search(question, k=3)
        answer = answer_question(question, relevant_chunks)
        print(f"\nAssistant: {answer}\n")


if __name__ == "__main__":
    main()
