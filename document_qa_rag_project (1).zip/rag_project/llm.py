"""
llm.py
------
Handles turning (question + retrieved chunks) into a final answer.

This project is designed to run in TWO modes so you can demo it even
without an API key:

  1. OFFLINE MODE (default, no key needed)
     Just shows the most relevant chunks as the "answer". This proves the
     retrieval half of RAG works, with zero setup.

  2. LLM MODE (set GROQ_API_KEY, or adapt call_llm() for OpenAI/Gemini)
     Sends the retrieved chunks + question to a real LLM so it can write a
     proper, natural-language answer grounded in your document.

Swap in any provider you like by editing call_llm() below — the rest of
the project doesn't care which one you use.
"""

import os
from typing import List
import requests

from rag_core import Chunk


GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")
GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_MODEL = "llama-3.1-8b-instant"  # free-tier Groq model, change if needed


def build_prompt(question: str, chunks: List[Chunk]) -> str:
    context = "\n\n".join(f"[Chunk {c.id}] {c.text}" for c in chunks)
    return (
        "Answer the question using ONLY the context below. "
        "If the answer isn't in the context, say you don't know.\n\n"
        f"Context:\n{context}\n\n"
        f"Question: {question}\n"
        "Answer:"
    )


def call_llm(prompt: str) -> str:
    """Send the prompt to Groq's free API. Requires GROQ_API_KEY to be set."""
    if not GROQ_API_KEY:
        raise RuntimeError("No GROQ_API_KEY set — running in offline mode instead.")

    response = requests.post(
        GROQ_URL,
        headers={"Authorization": f"Bearer {GROQ_API_KEY}"},
        json={
            "model": GROQ_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.2,
        },
        timeout=30,
    )
    response.raise_for_status()
    return response.json()["choices"][0]["message"]["content"].strip()


def is_generic_greeting(question: str) -> bool:
    """
    Tiny bit of 'agentic' decision-making: if the user is just saying hi,
    there's nothing to retrieve, so we skip the RAG pipeline entirely and
    answer directly. This is the same kind of branching real agents use to
    decide *whether* to call a tool (here: the retriever) before acting.
    """
    greetings = {"hi", "hello", "hey", "hii", "hola", "thanks", "thank you"}
    return question.strip().lower().strip("!.?") in greetings


def answer_question(question: str, chunks: List[Chunk]) -> str:
    """
    Decide how to answer:
      - generic greeting -> answer directly, no retrieval needed
      - real question     -> build a grounded prompt and call the LLM
                              (or fall back to showing the raw chunks)
    """
    if is_generic_greeting(question):
        return "Hi! Ask me a question about the document and I'll look it up for you."

    prompt = build_prompt(question, chunks)

    try:
        return call_llm(prompt)
    except RuntimeError:
        # Offline fallback: show what we retrieved, so the retrieval half
        # of the project is still fully visible and demoable.
        preview = "\n\n".join(f"- {c.text}" for c in chunks)
        return (
            "[Offline mode — no GROQ_API_KEY set, showing retrieved context "
            f"instead of an LLM-generated answer]\n\n{preview}"
        )
