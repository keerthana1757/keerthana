"""
rag_core.py
-----------
The heart of the Document Q&A Assistant.

This file does three things, in order:
  1. CHUNKING   -> break a document into small overlapping pieces of text.
  2. EMBEDDING  -> turn each chunk into a list of numbers (a "vector") using
                   TF-IDF, so that pieces of text with similar words end up
                   with similar vectors.
  3. RETRIEVAL  -> given a question, find which chunks are most similar to it
                   using FAISS (a fast vector search library).

This is the "R" (Retrieval) in RAG. The "AG" (Augmented Generation) part
happens in llm.py, which takes the retrieved chunks and asks an LLM to
answer using them.

Beginner note: real production systems usually use neural embeddings
(e.g. sentence-transformers) instead of TF-IDF, because they understand
meaning, not just matching words. TF-IDF is used here because it needs no
internet download and no GPU, so you can run this project on any laptop in
seconds. Swapping in sentence-transformers later is a natural "v2" upgrade
you can mention in an interview.
"""

from dataclasses import dataclass
from typing import List

import numpy as np
import faiss
from sklearn.feature_extraction.text import TfidfVectorizer


@dataclass
class Chunk:
    id: int
    text: str


def load_text(file_path: str) -> str:
    """Read a plain text file and return its contents as one string."""
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()


def chunk_text(text: str, chunk_size: int = 400, overlap: int = 80) -> List[Chunk]:
    """
    Split a long string into overlapping chunks.

    chunk_size: roughly how many characters go in each chunk.
    overlap:    how many characters repeat between consecutive chunks, so we
                don't accidentally cut a sentence in half and lose meaning.
    """
    text = " ".join(text.split())  # normalize whitespace
    chunks = []
    start = 0
    chunk_id = 0
    while start < len(text):
        end = start + chunk_size
        piece = text[start:end].strip()
        if piece:
            chunks.append(Chunk(id=chunk_id, text=piece))
            chunk_id += 1
        start += chunk_size - overlap
    return chunks


class VectorStore:
    """
    Wraps TF-IDF vectorization + a FAISS index so we can:
      1. build(chunks)          -> index all chunks once
      2. search(question, k)    -> get the k most relevant chunks
    """

    def __init__(self):
        self.vectorizer = TfidfVectorizer()
        self.index = None
        self.chunks: List[Chunk] = []

    def build(self, chunks: List[Chunk]) -> None:
        self.chunks = chunks
        texts = [c.text for c in chunks]

        # 1. Turn every chunk into a TF-IDF vector.
        tfidf_matrix = self.vectorizer.fit_transform(texts).toarray().astype("float32")

        # 2. FAISS compares vectors by distance, so we normalize them and use
        #    an inner-product index, which behaves like cosine similarity.
        faiss.normalize_L2(tfidf_matrix)
        dimension = tfidf_matrix.shape[1]
        self.index = faiss.IndexFlatIP(dimension)
        self.index.add(tfidf_matrix)

    def search(self, query: str, k: int = 3) -> List[Chunk]:
        if self.index is None:
            raise RuntimeError("VectorStore.build() must be called before search().")

        query_vec = self.vectorizer.transform([query]).toarray().astype("float32")
        faiss.normalize_L2(query_vec)

        k = min(k, len(self.chunks))
        _scores, indices = self.index.search(query_vec, k)
        return [self.chunks[i] for i in indices[0] if i != -1]
