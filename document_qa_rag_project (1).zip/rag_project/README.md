# Document Q&A Assistant (RAG-based)

A small Retrieval-Augmented Generation (RAG) project: ask questions about a text
document and get answers grounded in that document, instead of the model just
guessing from memory.

## How it works

1. **Chunking** (`rag_core.py`) — the document is split into overlapping chunks
   of text so we don't lose context at chunk boundaries.
2. **Embedding + Indexing** (`rag_core.py`) — each chunk is turned into a TF-IDF
   vector and stored in a **FAISS** index for fast similarity search.
3. **Retrieval** (`rag_core.py`) — when you ask a question, it's turned into a
   vector the same way, and FAISS returns the most similar chunks.
4. **Agentic branching** (`llm.py`) — a tiny decision step: if you're just
   saying "hi", the assistant skips retrieval entirely and replies directly.
   Otherwise it retrieves context first, then answers.
5. **Generation** (`llm.py`) — the question + retrieved chunks are sent to an
   LLM (Groq's free API by default) to produce a final natural-language
   answer. If no API key is set, it falls back to showing the raw retrieved
   chunks, so the retrieval half of the project is still demoable offline.

## Setup

```bash
pip install -r requirements.txt
```

## Run it (offline mode — no API key needed)

```bash
python app.py sample_docs/sample.txt
```

Then ask things like:
```
You: What does FlytBase do?
You: What is Retrieval-Augmented Generation?
```

## Run it with real LLM-generated answers

1. Get a free API key from https://console.groq.com
2. Set it as an environment variable:
   ```bash
   export GROQ_API_KEY="your-key-here"
   ```
3. Run the app again — answers will now be written by the LLM instead of
   showing raw chunks.

## Try it on your own document

```bash
python app.py path/to/your_file.txt
```

## Ideas to extend this (good talking points for interviews)

- Swap TF-IDF for a real neural embedding model (`sentence-transformers`) so
  retrieval understands meaning, not just matching words.
- Add PDF support (`pypdf`) so you can query PDFs directly.
- Add persistent memory so the assistant remembers earlier questions in the
  same session.
- Add a second "tool" (e.g. a calculator or web search) and let the agent
  decide which tool to use based on the question — a fuller multi-agent setup.
