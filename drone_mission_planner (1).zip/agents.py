"""
agents.py
---------
Two agents that together decide what every drone should do, each tick:

  CoordinatorAgent  -> decides WHICH drone should do WHICH task
                       (nearest available drone, highest priority task first)

  SafetyAgent       -> has the final say on whether that assignment is
                       actually allowed to happen. It can:
                         - block an assignment if the drone doesn't have
                           enough battery for the round trip, sending it
                           to recharge instead
                         - require human approval before sending a drone
                           into a restricted zone

This split mirrors how real agentic systems separate "what should we do"
(planning) from "is this allowed" (a safety/guardrail layer) — the JD's
line about "human-in-the-loop safety mechanisms" is exactly this second
agent's job.
"""

import math
from typing import List, Optional
from models import Drone, Task


def distance(a, b) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


class CoordinatorAgent:
    """Decides which idle drone should be sent to which pending task."""

    def propose_assignment(self, drones: List[Drone], tasks: List[Task]) -> Optional[tuple]:
        idle_drones = [d for d in drones if d.status == "idle"]
        pending_tasks = sorted(
            (t for t in tasks if t.status == "pending"),
            key=lambda t: t.priority,
        )

        if not idle_drones or not pending_tasks:
            return None

        # Highest-priority task first; pick the nearest idle drone to it.
        task = pending_tasks[0]
        nearest_drone = min(idle_drones, key=lambda d: distance(d.position, task.location))
        return nearest_drone, task


class SafetyAgent:
    """
    Reviews a proposed (drone, task) assignment before it's allowed to
    happen. Returns one of:
      "approved"          -> go ahead and assign the task
      "needs_recharge"     -> redirect the drone to base instead
      "needs_human_review"-> caller must ask a human before proceeding
      "rejected"           -> human said no; task stays pending
    """

    def __init__(self, battery_safety_margin: float = 15.0):
        self.battery_safety_margin = battery_safety_margin

    def estimate_round_trip_cost(self, drone: Drone, task: Task) -> float:
        out_and_back = distance(drone.position, task.location) * 2
        return out_and_back * drone.battery_per_unit

    def review(self, drone: Drone, task: Task) -> str:
        cost = self.estimate_round_trip_cost(drone, task)
        if drone.battery - cost < self.battery_safety_margin:
            return "needs_recharge"

        if task.restricted_zone:
            return "needs_human_review"

        return "approved"

    def ask_human(self, drone: Drone, task: Task) -> bool:
        """
        The actual human-in-the-loop step. In a CLI this is an input()
        prompt; in a real system this could be a Slack message or a
        dashboard approval button instead — the rest of the code doesn't
        need to change either way.
        """
        print(
            f"\n[SAFETY] Task {task.id} is in a RESTRICTED ZONE {task.location}. "
            f"Approve sending {drone.id} there? [y/n]"
        )
        answer = input("> ").strip().lower()
        return answer == "y"
