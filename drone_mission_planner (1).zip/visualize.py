"""
visualize.py
------------
Draws the final mission map: base, tasks (color-coded by outcome), and
each drone's full flight path.
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


TASK_COLORS = {
    "completed": "#2e8b57",   # green
    "cancelled": "#c0392b",   # red
    "pending": "#999999",     # gray (shouldn't normally remain at the end)
    "assigned": "#e67e22",    # orange
    "in_progress": "#e67e22",
}

DRONE_COLORS = ["#1f77b4", "#9467bd", "#17becf", "#bcbd22", "#8c564b"]


def plot_mission(drones, tasks, base, save_path="output/mission_map.png"):
    fig, ax = plt.subplots(figsize=(7, 7))

    # Base
    ax.scatter(*base, marker="s", s=160, c="black", zorder=5, label="Base")

    # Tasks
    for task in tasks:
        color = TASK_COLORS.get(task.status, "#999999")
        marker = "^" if task.restricted_zone else "o"
        ax.scatter(*task.location, marker=marker, s=140, c=color, edgecolors="black", zorder=4)
        ax.annotate(task.id, task.location, textcoords="offset points", xytext=(6, 6), fontsize=8)

    # Drone paths
    for i, drone in enumerate(drones):
        color = DRONE_COLORS[i % len(DRONE_COLORS)]
        xs = [p[0] for p in drone.path]
        ys = [p[1] for p in drone.path]
        ax.plot(xs, ys, "-", color=color, linewidth=1.6, alpha=0.85, label=drone.id, zorder=3)
        ax.scatter(xs[-1], ys[-1], color=color, s=60, zorder=6)

    ax.set_title("Drone Fleet Mission Map\n(triangle = restricted zone, square = base)")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.legend(loc="upper left", fontsize=8, framealpha=0.9)
    ax.set_aspect("equal")
    ax.grid(alpha=0.25)

    fig.tight_layout()
    fig.savefig(save_path, dpi=150)
    print(f"Saved mission map to {save_path}")
