# Multi-Agent Drone Mission Planner (Simulated Fleet)

A simulated fleet of drones is given a list of inspection tasks. Two agents
work together to decide what happens, tick by tick — no real drone hardware
needed, everything is a lightweight simulation you can run on any laptop.

## Why this project

Built specifically around what an **Agentic AI Engineer** role at a drone
company actually needs: real multi-agent decision-making, applied to the
drone/inspection domain, with a genuine human-in-the-loop safety layer —
not just a single LLM wrapped in a chat interface.

## The two agents

- **CoordinatorAgent** (`agents.py`) — decides *which* idle drone should be
  sent to *which* pending task, based on task priority and distance.
- **SafetyAgent** (`agents.py`) — has the final say before any assignment
  actually happens:
  - If a drone doesn't have enough battery for the round trip, the
    assignment is blocked and the drone is redirected to recharge instead.
  - If a task is inside a restricted zone, a human must explicitly approve
    it before the drone is allowed to go — the actual
    "human-in-the-loop safety mechanism" pattern.

## Files

- `models.py` — `Drone` and `Task` data classes.
- `agents.py` — the two agents described above.
- `simulation.py` — the tick-by-tick world engine: moves drones, calls the
  agents, handles arrivals, recharging, and task completion.
- `visualize.py` — draws the final mission map (base, tasks, flight paths).
- `main.py` — sets up a sample fleet + task list (including one restricted
  zone task) and runs everything.

## Run it

```bash
pip install matplotlib
python main.py
```

You'll be asked in the terminal to approve or reject the restricted-zone
mission — try both `y` and `n` on different runs to see how the system
reacts differently each time. A `output/mission_map.png` image is saved
showing each drone's flight path and every task's outcome.

## Try changing things

- Lower a drone's starting `battery` in `main.py` and watch it get redirected
  to recharge before being sent anywhere.
- Add more tasks or drones to `build_tasks()` / `build_fleet()`.
- Change `battery_safety_margin` in `SafetyAgent` to make the system more or
  less cautious.

## Possible extensions

- Swap the simple rule-based CoordinatorAgent for an LLM-based planner that
  reasons about trade-offs in natural language.
- Add no-fly time windows (e.g. restricted only during certain hours).
- Model multiple bases and let drones return to whichever is nearest.
- Replace the static map with a live animated visualization.
