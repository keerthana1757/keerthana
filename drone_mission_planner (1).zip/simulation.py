"""
simulation.py
-------------
Runs the world forward one "tick" at a time:

  1. Move every drone that's currently traveling, a little closer to
     wherever it's going.
  2. Ask the CoordinatorAgent if any idle drone should start a new task.
  3. Ask the SafetyAgent to review that proposal before it's allowed.
  4. Handle arrivals: finishing an inspection, finishing a recharge.

This file has no AI/ML in it on purpose — it's the deterministic "world
engine". The interesting decision-making lives entirely in agents.py,
which is the part worth highlighting in an interview.
"""

from agents import CoordinatorAgent, SafetyAgent, distance
from models import Drone, Task

INSPECT_DURATION_TICKS = 3
CHARGE_RATE_PER_TICK = 20.0
ARRIVAL_THRESHOLD = 0.5


class Simulation:
    def __init__(self, drones, tasks, max_ticks=200):
        self.drones = drones
        self.tasks = tasks
        self.max_ticks = max_ticks
        self.coordinator = CoordinatorAgent()
        self.safety = SafetyAgent()
        self.tick_num = 0
        self.log = []

    def _move_toward(self, drone: Drone, target):
        d = distance(drone.position, target)
        if d <= drone.speed:
            drone.position = target
        else:
            ratio = drone.speed / d
            new_x = drone.position[0] + (target[0] - drone.position[0]) * ratio
            new_y = drone.position[1] + (target[1] - drone.position[1]) * ratio
            drone.position = (new_x, new_y)
        drone.path.append(drone.position)

    def _task_by_id(self, task_id) -> Task:
        return next(t for t in self.tasks if t.id == task_id)

    def step(self):
        self.tick_num += 1

        # 1. Advance drones that are already moving or busy.
        for drone in self.drones:
            if drone.status == "en_route":
                task = self._task_by_id(drone.target_task_id)
                drone.battery -= drone.battery_per_unit * min(drone.speed, distance(drone.position, task.location))
                self._move_toward(drone, task.location)
                if distance(drone.position, task.location) < ARRIVAL_THRESHOLD:
                    drone.status = "inspecting"
                    drone.inspect_ticks_left = INSPECT_DURATION_TICKS
                    task.status = "in_progress"
                    self.log.append(f"t={self.tick_num}: {drone.id} arrived at {task.id}, inspecting.")

            elif drone.status == "inspecting":
                drone.inspect_ticks_left -= 1
                if drone.inspect_ticks_left <= 0:
                    task = self._task_by_id(drone.target_task_id)
                    task.status = "completed"
                    drone.target_task_id = None
                    drone.status = "idle"
                    self.log.append(f"t={self.tick_num}: {drone.id} completed {task.id}.")

            elif drone.status == "returning":
                drone.battery -= drone.battery_per_unit * min(drone.speed, distance(drone.position, drone.base))
                self._move_toward(drone, drone.base)
                if distance(drone.position, drone.base) < ARRIVAL_THRESHOLD:
                    drone.status = "charging"
                    self.log.append(f"t={self.tick_num}: {drone.id} back at base, charging.")

            elif drone.status == "charging":
                drone.battery = min(100.0, drone.battery + CHARGE_RATE_PER_TICK)
                if drone.battery >= 99.9:
                    drone.status = "idle"
                    self.log.append(f"t={self.tick_num}: {drone.id} fully charged, ready.")

        # 2 & 3. Try to hand out a new assignment this tick.
        proposal = self.coordinator.propose_assignment(self.drones, self.tasks)
        if proposal:
            drone, task = proposal
            decision = self.safety.review(drone, task)

            if decision == "needs_recharge":
                drone.status = "returning"
                self.log.append(
                    f"t={self.tick_num}: [SAFETY] {drone.id} lacks battery for {task.id} "
                    f"-> sent to recharge instead."
                )
            elif decision == "needs_human_review":
                approved = self.safety.ask_human(drone, task)
                if approved:
                    task.status = "assigned"
                    drone.status = "en_route"
                    drone.target_task_id = task.id
                    self.log.append(
                        f"t={self.tick_num}: [SAFETY] human approved {drone.id} -> {task.id} (restricted zone)."
                    )
                else:
                    task.status = "cancelled"
                    self.log.append(
                        f"t={self.tick_num}: [SAFETY] human rejected {task.id}; task cancelled."
                    )
            elif decision == "approved":
                task.status = "assigned"
                drone.status = "en_route"
                drone.target_task_id = task.id
                self.log.append(f"t={self.tick_num}: {drone.id} assigned to {task.id}.")

    def all_tasks_resolved(self) -> bool:
        return all(t.status in ("completed", "cancelled") for t in self.tasks)

    def run(self):
        while self.tick_num < self.max_ticks and not self.all_tasks_resolved():
            self.step()
        return self.log
