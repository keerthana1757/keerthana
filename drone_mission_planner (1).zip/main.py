"""
main.py
-------
Sets up a sample fleet + a list of inspection tasks (including one in a
restricted zone, to demonstrate the human-in-the-loop safety check), runs
the simulation to completion, prints a decision log, and saves a mission
map image.

Run it:
    python main.py
"""

import os
from models import Drone, Task
from simulation import Simulation
from visualize import plot_mission

BASE = (0.0, 0.0)


def build_fleet():
    return [
        Drone(id="Drone-A", base=BASE, battery=100.0),
        Drone(id="Drone-B", base=BASE, battery=60.0),   # starts with lower battery on purpose
    ]


def build_tasks():
    return [
        Task(id="Site-1", location=(8, 3), priority=2),
        Task(id="Site-2", location=(-6, 5), priority=1),
        Task(id="Site-3", location=(10, -9), priority=3, restricted_zone=True),
        Task(id="Site-4", location=(3, 7), priority=2),
    ]


def main():
    os.makedirs("output", exist_ok=True)

    drones = build_fleet()
    tasks = build_tasks()

    sim = Simulation(drones, tasks, max_ticks=200)
    log = sim.run()

    print("\n----- MISSION LOG -----")
    for line in log:
        print(line)

    print("\n----- FINAL TASK STATUS -----")
    for t in tasks:
        print(f"{t.id}: {t.status}" + (" (restricted zone)" if t.restricted_zone else ""))

    plot_mission(drones, tasks, BASE)


if __name__ == "__main__":
    main()
