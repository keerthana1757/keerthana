"""
models.py
---------
The basic "things" in our simulated world: Drone and Task.

Beginner note: these are plain data containers (dataclasses). All the
actual decision-making logic lives in agents.py, not here — keeping data
and behavior separate makes the system easier to reason about, which is
exactly how real multi-agent systems are usually structured.
"""

from dataclasses import dataclass, field
from typing import Optional, Tuple


@dataclass
class Task:
    id: str
    location: Tuple[float, float]
    priority: int              # 1 = highest priority
    restricted_zone: bool = False
    status: str = "pending"    # pending -> assigned -> in_progress -> completed / cancelled


@dataclass
class Drone:
    id: str
    base: Tuple[float, float]
    position: Tuple[float, float] = field(default=None)
    battery: float = 100.0
    speed: float = 3.0            # distance units moved per tick
    battery_per_unit: float = 0.6  # battery % consumed per unit distance traveled
    status: str = "idle"          # idle -> en_route -> inspecting -> returning -> charging
    target_task_id: Optional[str] = None
    inspect_ticks_left: int = 0
    path: list = field(default_factory=list)  # history of positions, for plotting

    def __post_init__(self):
        if self.position is None:
            self.position = self.base
        self.path.append(self.position)
